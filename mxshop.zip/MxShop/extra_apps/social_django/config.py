from django.apps import AppConfig


class PythonSocialAuthConfig(AppConfig):
    name = 'social'
    label = 'social_auth'
    verbose_name = 'Python Social Auth'
